import math

primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41,
          43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]

# RSA Encryption

p = 13
q = 23

n = p * q
phi_n = (p - 1) * (q - 1)

e = 5
for d in range(phi_n // e, phi_n - 1):
    if d * e % phi_n == 1:
        break

print("Test d: ", e * d % phi_n == 1)

m = 18
c = (m ** e) % n  # pow(m, e, n)

print("The ciphertext of {} is {}".format(m, c))

print("The plaintext of {} is {}".format(c, c ** d % n))
