#!/bin/bash

#openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out rsa-key.pem -aes-128-cbc 
#openssl pkey -in rsa-key.pem -pubout -out rsa-key.pub

#echo "Your RSA encrypted private key is: rsa-key.pem, public key is rsa-key.pub!"
#echo -e "\nSigning: specify private key in the 1st argument, File in the 2nd argument, Sig in the 3rd argument\n"

echo -e "You need to privde the following arguments.\n"
echo "Priviate key: "
read pri_key
echo "File Name: "
read file_name
echo "Signature Name: "
read sig_name
openssl dgst -sha256 -sign $pri_key -out $sig_name $file_name 
