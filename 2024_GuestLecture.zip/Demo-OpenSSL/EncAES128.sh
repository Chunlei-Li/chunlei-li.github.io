#!/bin/bash

openssl enc -aes-128-cbc -in $1 -out $2 -pbkdf2
